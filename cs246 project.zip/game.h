#ifndef GAME_H
#define GAME_H
#include <fstream>
#include "floor.h"
#include "object.h"
#include "player.h"

class gameNotification{
public:
	virtual void updateCell(int row, int col, char ch) = 0;
};

const int ROWS = 25;
const int COLS = 79;

class Game{
	//Enemy *listEnemy;
  Floor *floor;
  //int floorsCleared;
  //Item *listItem
 	gameNotification* notification;
  std::ifstream *ifs;
  Player *player;
  //void enemyTurn();
  //void finishedFloor();
  void spawnAll();
  int spawnStair();
  void spawnPlayer(int stairchamber);
  void spawnObject(Object* object);
public:
  Game(char race, gameNotification* notification);
  Game(std::ifstream *ifs, char race, gameNotification* notification);
  ~Game();
  int rng(int mod);
  void printStatus();
  void playerTurn(std::string s);
	void updateView(int row, int col, char ch);
};

#endif
