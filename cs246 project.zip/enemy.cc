#include "enemy.h"
#include "player.h"
#include <cmath>
#include <vector>
 
int Enemy::getAtk(){
    return atk;
}
 
int Enemy::getDef(){
    return def;
}
 
bool Enemy::isDead(){
    return hp <= 0;
}
 
bool Enemy::getAgressive(){
    return aggressive;
}
 
void Enemy::setHP(int hp){
    this->hp = hp;
}
 
Enemy::~Enemy(){}

void Enemy::Move(){
    std::vector<Cell *> temp;
    for(int i = 0; i < 8; i++){
        if(cell->getNeighbours()[i]->getBaseType() == '.' && cell->getNeighbours()[i]->getObject() == NULL){
            temp.push_back(cell->getNeighbours()[i]);
        }
    }
    
    if(temp.size() == 0){
        return;
    }
    
    cell->removeObject();
    cell = temp.at(game->rng(temp.size()));
    row = cell->getRow();
    col = cell->getCol();
    cell->setObject(this);
    
}

bool Enemy::Defend(Player &player){
    if(type == 'L'){
        if(game->rng(2) == 1){
            player.atkEnemy(this);
            return true;
        }
        return false;
    }
    else{
        player.atkEnemy(this);
        return true;
    }
}

void Enemy::atkPlayer(Player &player){
    player.setHP(player.getHP() - (ceil((100/float(100+ player.getDef()))) * getAtk()));
}

