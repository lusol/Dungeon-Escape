#include "treasure.h"

Treasure::Treasure(Game *game, int val){
	value = val;
	this-game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = 'G';
	canPickup = true;
}

void Treasure::pickedUp(){
	if(canPickup == true){
		game->player->setGold(game->player->getGold()+value);
	}
}
