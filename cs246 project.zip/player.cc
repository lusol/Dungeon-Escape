#include "player.h"
#include "enemy.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "goblin.h"
#include "troll.h"
#include <cmath>

Player::~Player() {delete pe;}

int Player::getMaxHP(){
    return maxHP;
}
int Player::getAtk(){
    return atk;
}

int Player::getDef(){
    return def;
}

int Player::getHP(){
    return hp;
}

void Player::setMaxHP(int hp){
    maxHP = hp;
}
void Player::setHP(int hp){
    this->hp = hp;
}
void Player::setGold(int gold){
    this->gold = gold;
}

Player* Player::PlayerFactory(char race, Game* game){
    Player* output;
    switch (race){
    case 's':
        output = new Shade(game);
        break;
    case 'd':
        output = new Drow(game);
        break;
    case 'v':
        output = new Vampire(game);
        break;
    case 'g':
        output = new Goblin(game);
        break;
    case 't':
        output = new Troll(game);
        break;
    default:
        output = new Shade(game);
        break;
    }
    return output;
}

void Player::Move(std::string direction){
    if(direction == "no"){
        setCoords(cell->getNeighbours()[1]->getRow(),cell->getNeighbours()[1]->getCol());
        cell = cell->getNeighbours()[1];
    }
    else if(direction == "so"){
        setCoords(cell->getNeighbours()[5]->getRow(),cell->getNeighbours()[5]->getCol());
        cell = cell->getNeighbours()[5];
    }
    else if(direction == "ea"){
        setCoords(cell->getNeighbours()[3]->getRow(),cell->getNeighbours()[3]->getCol());
        cell = cell->getNeighbours()[3];
    }  
    else if(direction == "we"){
        setCoords(cell->getNeighbours()[7]->getRow(),cell->getNeighbours()[7]->getCol());
        cell = cell->getNeighbours()[7];
    }
    else if(direction == "ne"){
        setCoords(cell->getNeighbours()[2]->getRow(),cell->getNeighbours()[2]->getCol());
        cell = cell->getNeighbours()[2];
    }
    else if(direction == "se"){
        setCoords(cell->getNeighbours()[4]->getRow(),cell->getNeighbours()[4]->getCol());
        cell = cell->getNeighbours()[4];
    }
    else if(direction == "nw"){
        setCoords(cell->getNeighbours()[0]->getRow(),cell->getNeighbours()[0]->getCol());
        cell = cell->getNeighbours()[0];
    }
    else if(direction == "sw"){
        setCoords(cell->getNeighbours()[6]->getRow(),cell->getNeighbours()[6]->getCol());
        cell = cell->getNeighbours()[6];
    }
}

void Player::atkEnemy(Enemy *enemy){
    enemy->setHP(getHP() - (ceil((100/float(100+ enemy->getDef()))) * getAtk()) );
}


bool Player::Defend(Enemy *enemy){
if(game->rng(2) == 0){
    enemy->atkPlayer(*this);
    return true;
} else{
    return false;
}
}
