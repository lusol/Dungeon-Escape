#ifndef MERCHANT_H
#define MERCHANT_H

class Game;
class Player;

class Merchant : public Enemy{
public:
    Merchant(Game *game);
    void attack(Player &player);
};

#endif