#include "enemy.h"
#include "dwarf.h"
#include "player.h"

Dwarf::Dwarf(Game *game){
     this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'W';
    atk = 20;
    def = 30;
    hp = 100;
    aggressive = true;
}
void Dwarf::attack(Player *player){
    player->Defend(this);
}