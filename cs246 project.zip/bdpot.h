#ifndef BDPOT_H
#define BDPOT_H
#include "potion.h"
class BDPot:public Potion{
static bool revealed;
public:
BDPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};

#endif