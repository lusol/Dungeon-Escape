#ifndef WAPOT_H
#define WAPOT_H
#include "potion.h"
class WAPot:public Potion{
static bool revealed;
public:
WAPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};
#endif