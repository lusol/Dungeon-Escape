#include "drow.h"
#include "enemy.h"

Drow::Drow(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'd';
    atk = 25;
    def = 15;
    maxHP = 150;
    hp = 150;
    gold = 0;
    pe = NULL;
}

void Drow:: Attack(Enemy *enemy){
	enemy->Defend(*this);
}
