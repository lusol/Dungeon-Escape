#include "human.h"
#include "player.h"

Human::Human(Game* game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'H';
    atk = 20;
    def = 20;
    hp = 140;
    aggressive = true;
}

void Human::attack(Player *player){
    player->Defend(this);
}
