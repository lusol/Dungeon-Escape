#ifndef DRAGON_H
#define DRAGON_H


class Dragon::public Enemy{
    DragonTreasure *treasure;
    public:
    Dragon(Game *game, DragonTreasure *treasure);
    void attack(Player &player);
    void Move();
};

#endif