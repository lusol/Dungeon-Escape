#ifndef SHADE_H
#define SHADE_H
#include "player.h"

class Game;
class Enemy;

class Shade : public Player{
public:
  Shade(Game *game);
  ~Shade();
  void Attack (Enemy *enemy);
};

#endif

