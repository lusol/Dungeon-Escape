#include "Enemy.h"
 class Treasure;

Dragon::Dragon(Game *game, Dragontreasure *treasure){
    this->game = game;
    this->treasure = treasure;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'D';
    atk = 20;
    def = 20;
    hp = 150;
    aggressive = true;
}
void Dragon::attack(Player *player){
    player->defend(*this);
}
void Dragon::Move(){}


