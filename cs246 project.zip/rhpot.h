#ifndef RHPOT_H
#define RHPOT_H
#include "potion.h"
class RHPOT:public Potion{
static bool revealed;
public:
RHPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};

#endif