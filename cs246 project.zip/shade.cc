#include "shade.h"
#include "enemy.h"

Shade::Shade(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    atk = 25;
    def = 25;
    type = 's';
    maxHP = 125;
    hp = 125;
    gold = 0;
    pe = new PotionEffect(atk, def);
}

void Shade::Attack(Enemy *enemy){
    enemy->Defend(*this);
}

Shade::~Shade(){}

