#ifndef VIEW_H
#define VIEW_H

class View{
  char **grid;
  int rowSize ;
  int colSize ;
public:
  View(int rowSize, int colSize);
  ~View();
  void printout();
  void updateCell(int row, int column, char ch);
};

#endif
