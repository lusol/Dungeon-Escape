#include "bapot.h"
#include <iostream>

BAPot::BAPot(Game *game){
	this->game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = '1';
	canPickup = true;
	revealed = false;
}

void BAPot::pickedup(){
	if(game->player->getType() == 'd'){
		game->player->pe->setAtk(game->player->pe->getAtk()+7);
	}
	{
		game->player->pe->setAtk(game->player->pe->getAtk()+5);
	}
	
}
bool BAPot::isRevealed(){
	return revealed;
}

void BAPot::switchRevealed(){
	revealed = !revealed;
}