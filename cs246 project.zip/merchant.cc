#include "enemy.h"
#include "player.h"
#include "merchant.h"

Merchant::Merchant(Game *game){
     this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'M';
    atk = 70;
    def = 5;
    hp = 30;
    aggressive = false;
}
void Merchant::attack(Player &player){
    player.Defend(this);
}
