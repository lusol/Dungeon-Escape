#ifndef GOBLIN_H
#define GOBLIN_H
#include "player.h"

class Enemy;
class Game;

class Goblin : public Player{
public:
  Goblin(Game *game);
  void Attack(Enemy *enemy);
};

#endif



