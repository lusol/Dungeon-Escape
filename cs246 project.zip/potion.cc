#include "potion.h"

Potion::~Potion(){}