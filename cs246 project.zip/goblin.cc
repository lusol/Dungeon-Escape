#include "goblin.h"
#include "enemy.h"

Goblin::Goblin(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'g';
    atk = 15;
    def = 20;
    maxHP = 110;
    hp = 110;
    gold = 0;
    pe = NULL;
}

void Goblin:: Attack(Enemy *enemy){
    enemy->Defend(*this);
    if(enemy->isDead() == true){
        gold += 5;
    }
}