
#include "wapot.h"
#include <iostream>
WAPot::WAPot(Game *game){
	this->game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = '4';
	canPickup = true;
	revealed = false;
}

void WAPot::pickedup(){
	if(game->player->getType() == 'd'){
		game->player->pe->setAtk(game->player->pe->getAtk()-7);
	}
	{
		game->player->pe->setAtk(game->player->pe->getAtk()-5);
	}
	
}
bool WAPot::isRevealed(){
	return revealed;
}

void WAPot::switchRevealed(){
	revealed = !revealed;
}