
#ifndef BAPOT_H
#define BAPOT_H
#include "potion.h"
class BAPot:public Potion{
static bool revealed;
public:
BAPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};

#endif