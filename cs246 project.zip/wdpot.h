












#ifndef WDPOT_H
#define WDPOT_H
#include "potion.h"
class WDPot:public Potion{
static bool revealed;
public:
WDPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};
#endif