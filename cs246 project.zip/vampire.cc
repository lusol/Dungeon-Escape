#include "vampire.h"
#include "enemy.h"

Vampire::Vampire(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'v';
    atk = 25;
    def = 15;
    maxHP = 0;
    hp = 150;
    gold = 0;
    pe = NULL;

}

void Vampire::Attack(Enemy *enemy){
	if(enemy->Defend(*this) == true){
        if(enemy->getType() == 'W'){
            setHP(getHP()-5);
        }
        else{
            setHP(getHP()+5);
        }
    }
}