#include "potioneffect.h"

PotionEffect::PotionEffect(int atk, int def){
	this->atk = atk;
	this->def = def;
}

PotionEffect::~PotionEffect(){}

void PotionEffect::setAtk(int atk){
	if(atk<0){
		this->atk = 0;
	}
	else{
	this->atk = atk;
	}
}

void PotionEffect::setDef(int def){
if(def<0){
	this->def = 0;
}
else{
	this->def = def;
}
}
int PotionEffect::getAtk(){return atk;}
int PotionEffect::getDef(){return def;}
