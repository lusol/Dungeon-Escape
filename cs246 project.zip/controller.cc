#include "controller.h"
#include <fstream>

using namespace std;

Controller::Controller(string filename){
	fileName = filename;
	game = NULL;
  view = NULL;
}

Controller::Controller(){
  fileName = "";
  game = NULL;
  view = NULL;
}

void Controller::updateCell(int row, int col, char ch){
	view->updateCell(row, col, ch);	
}

void Controller::init(){ 
  if (fileName != "") cout << "Loaded map " << fileName << endl;

  cout << "Select your race: ";
  char c;
  cin >> c;
  
  view = new View(ROWS, COLS);
  if (fileName != "") { //initalizes game either with or without a file
  	ifstream ifs(fileName.c_str());
    game = new Game(&ifs, c, this);
  } else game = new Game(c, this);
}

void Controller::play(){  
  init();
  
	while(1){ //main command loop
  	cout << "Command: ";
  	string s;
    cin >> s;

    if (s == "q" || cin.eof()){
			if (game != NULL) delete game;
      if (view != NULL) delete view;
      break;
    } else if (s == "r"){
    	delete game;
      delete view;
      init();
    } else if (s == "p"){
    	view->printout();
    }
    else {
    	game->playerTurn(s);
    }
  }
}

Controller::~Controller(){}
