

#include "phpot.h"
#include <iostream>

PHPot::PHPot(Game *game){
	this->game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = '3';
	canPickup = true;
	revealed = false;
}
void PHPot::pickedup(){
	if(game->player->getType() == 'd'){
		if(game->player->getHP() <= 15){
			game->player->setHP(1);
		}
		else{
			game->player->setHP(getHP()-15);
		}
	}
	{
		if(game->player->getHP() <= 10){
			game->player->setHP(1);
		}
		else{
			game->player->setHP(getHP()-10);
		}	
	}
	
}
bool PHPot::isRevealed(){
	return revealed;
}

void PHPot::switchRevealed(){
	revealed = !revealed;
}