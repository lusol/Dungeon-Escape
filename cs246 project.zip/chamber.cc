#include "chamber.h"
#include <iostream>

Chamber::Chamber(){}

bool Chamber::getFull(){
	for (int i = 0; i < cells.size(); i++){
		if (cells[i]->getObject() == NULL) return false;
	}
	return true;
}

void Chamber::setCells(Cell* cell){
	if (cell->getBaseType() == '.') {
		cells.push_back(cell);
		for (int i = 0; i < 8; i++){
			if ((cell->getNeighbours())[i] == NULL) break;
			else if (!isMember((cell->getNeighbours())[i])){
				setCells((cell->getNeighbours())[i]);
			}
		}
	}
}

bool Chamber::isMember(Cell* cell){
	for (int i = 0; i < cells.size(); i++){
		if (cells[i] == cell) return true;
	}
	return false;
}

void Chamber::printVector(){
	for (int i = 0; i < cells.size(); i++){
		std::cout << cells[i]->getRow() << " " << cells[i]->getCol() << ":" << cells[i]->getBaseType() << std::endl; 
	}
}

bool Chamber::isEmpty(){
	return cells.size() == 0;
}

std::vector<Cell*>& Chamber::getCells(){
	return cells;
}

Chamber::~Chamber(){}
