#include "enemy.h"
#include "player.h"
#include "orc.h"

Orc::Orc(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'O';
    atk = 30;
    def = 25;
    hp = 180;
    aggressive = true;
}
void Orc::attack(Player &player){
    player.Defend(this);
}
