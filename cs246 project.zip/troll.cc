#include "troll.h"
#include "enemy.h"

Troll::Troll(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 't';
    atk = 25;
    def = 15;
    maxHP = 120;
    hp = 120;
    gold = 0;
    pe = NULL;

}

void Troll:: Attack(Enemy *enemy){
    enemy->Defend(*this);
}