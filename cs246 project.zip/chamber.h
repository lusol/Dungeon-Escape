#include "cell.h"
#include <vector>

class Chamber {
	std::vector<Cell*> cells;
public:	
	Chamber();
	bool getFull();
	void setCells(Cell* cell);
	bool isMember(Cell* cell);
	bool isEmpty();
	std::vector<Cell*>& getCells();
	void printVector();
	~Chamber();
};
