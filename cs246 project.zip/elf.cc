#include "enemy.h"
#include "elf.h"
#include "player.h"

Elf::Elf(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'E';
    atk = 30;
    def = 0;
    hp = 140;
    aggressive = true;
}

void Elf::attack(Player &player){
    if(player.getType() == 'd'){
      player.Defend(this);
    } else{
      player.Defend(this);
      player.Defend(this);
    }
}