#ifndef ENEMY_H
#define ENEMY_H
#include "game.h"

class Player;

class Enemy : public Object {
	protected:
		int hp,atk,def;
		bool aggressive;
	public:
		bool getAgressive();
		int getAtk();
		int getDef();
		bool isDead();
		void setHP(int hp);
		void atkPlayer(Player& player);
		bool Defend(Player& player);
		void Move();
		virtual ~Enemy() = 0;
};

#endif