#include "dragontreasure.h"
#include <iostream>
dragonTreasure::dragonTreasure(Game *game, int val){
	this->game = game;
	canPickup = false;
	dragon = NULL;
	dragonSlain = false;
	cell = NULL;
	row = -1;
	col = -1;
	type = 'D';
}

void dragonTreasure::switchPickup(){
	canPickup = !canPickup;
}
void dragonTreasure::pickedUp(){
	if(canPickup == true){
		game->player->setGold(game->player->getGold()+value);
	}
}

void dragonTreasure::spawnDragon(){
	dragon = new Dragon(game, this);
	std::vector<Cell *> temp;
    for(int i = 0; i < 8; i++){
        if(cell->getNeighbours()[i]->getBaseType() == '.' && cell->getNeighbours()[i]->getObject() == NULL){
            temp.push_back(cell->getNeighbours()[i]);
        }
    }
     
     

    dragon->cell = temp.at(game->rng(temp.size()));
    dragon->setRow(dragon->cell->getRow());
    dragon->setcol(dragon->cell->getCol());


    cell->setObject(dragon);
}