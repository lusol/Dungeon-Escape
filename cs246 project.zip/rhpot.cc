#include "rhpot.h"
#include <iostream>

RHPot::RHPot(Game *game){
	this->game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = '0';
	canPickup = true;
	revealed = false;
}
void RHPot::pickedup(){
	if(game->player->getType() == 'd'){
		if(game->player->getHP() >= 135){
			game->player->setHP(150);
		}
		else{
			game->player->setHP(getHP()+15);
		}
	}
	{
		if(game->player->getHP() >= game->player->getMaxHP() - 10){
			game->player->setHP(game->player->getMaxHP());
		}
		else{
			game->player->setHP(getHP()+10);
		}	
	}
	
}
bool RHPot::isRevealed(){
	return revealed;
}

void RSSHPot::switchRevealed(){
	revealed = !revealed;
}