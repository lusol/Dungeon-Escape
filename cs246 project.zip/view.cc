#include "view.h"
#include <iostream>
using namespace std;

View::View(int rowSize, int colSize){
    this->colSize = colSize;
    this->rowSize = rowSize;

    grid = new char*[rowSize];
    for (int i = 0; i < rowSize; i++){
        grid[i] = new char[colSize];
    }

    for (int i = 0; i < rowSize; i++){
        for (int j = 0; j < colSize; j++){
            grid[i][j] = '0';
        }
    }
}

View::~View(){
    for (int i = 0; i < rowSize; i++){
        delete[] grid[i];
    }
    delete[] grid;
}

void View::updateCell(int row, int col, char ch){
    grid[row][col] = ch;
}

void View::printout(){
    for (int i = 0; i < rowSize; i++){
        for (int j = 0; j < colSize; j++){
            cout<<grid[i][j];
        }
        cout << endl;
    }
}