#include "game.h"
#include "enemy.h"
#include "shade.h"
#include "human.h"
#include "dwarf.h"
#include "halfling.h"
#include "elf.h"
#include "orc.h"
#include "merchant.h"
#include <cstdlib>
#include <ctime>
#include <vector>

using namespace std;

Game::Game(char race, gameNotification* notification){
	srand(time(NULL));
	this->notification = notification;
	player = Player::PlayerFactory(race, this);
	floor = new Floor(this, ROWS, COLS);
	spawnAll();
}

Game::Game (std::ifstream *ifs, char race, gameNotification* notification){
	srand(time(NULL));
	this->notification = notification;
	player = Player::PlayerFactory(race, this);
	this->ifs = ifs;
	floor = new Floor(this, ROWS, COLS, *ifs);
}

void Game::spawnAll(){
	spawnPlayer(spawnStair());
	for(int i = 0; i < 20; i++){
		int monsternum = rng(18);
		Object* object;
		if (monsternum < 4) object = new Human(this);
		else if (monsternum < 7) object = new Dwarf(this);
		else if (monsternum < 12) object = new Halfling(this);
		else if (monsternum < 14) object = new Elf(this);
		else if (monsternum < 16) object = new Orc(this);
		else object = new Merchant(this);
		spawnObject(object);
	}
}

void Game::spawnPlayer(int stairchamber){
	int chamberNum = rng(5);
	while (chamberNum == stairchamber) {chamberNum = rng(5);}
	Chamber* chambers = floor->getChambers();
	std::vector<Cell*> cells = chambers[chamberNum].getCells();
	int cellNum = rng(cells.size());
	cells[cellNum]->setObject(player);
}

int Game::spawnStair(){
	Chamber* chambers = floor->getChambers();
	int chamberNum = rng(5);
	std::vector<Cell*> cells = chambers[chamberNum].getCells();
	int cellNum = rng(cells.size());
	cells[cellNum]->setBaseType('/');

	return chamberNum;
}	

void Game::spawnObject(Object* object){
	Chamber* chambers = floor->getChambers();
	while(1){
		int chamberNum = rng(5);
		if (!chambers[chamberNum].getFull()){
			std::vector<Cell*> cells = chambers[chamberNum].getCells();
			std::vector<Cell*> valid;
			for (int i = 0; i < cells.size(); i++){
				if (cells[i]->getObject() == NULL && cells[i]->getBaseType() != '/') valid.push_back(cells[i]);
			}
			int cellNum = rng(valid.size());
			valid[cellNum]->setObject(object);
			return;
		}
	}
}

int Game::rng(int mod){
	return rand() % mod;
}

Game::~Game(){
	if (floor != NULL) delete floor;
}

void Game::updateView(int row, int col, char ch){
	notification->updateCell(row, col, ch);
}

void Game::printStatus(){

}

void Game::playerTurn(string s){
	/*
	if (s == "a"){
		string direction;
		cin >> direction;
		player->attack()
	} else if (s == "u") {
		string direction;
		cin >> direction;
		player->use(direction);
	} else {
		player->move(s);
	*/
}

