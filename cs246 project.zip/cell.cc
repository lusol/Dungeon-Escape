#include "cell.h"
#include "floor.h"
#include <iostream>

Cell::Cell(){
	floor = NULL;
	row = 0;
	col = 0;
	baseType = 0;
	floor = NULL;
	object[0] = NULL;
	object[1] = NULL;
	for (int i = 0; i < 8; i++){
		neighbours[i] = NULL;
	}
}

void Cell::init(Floor *floor, int row, int col, char ch){
  this->floor = floor;
  this->row = row;
  this->col = col;
  baseType = ch;
}

void Cell::setObject(Object* object){
	char ch = object->getType();
	if (ch == 's' || ch == 'd' || ch == 'v' || ch == 't' || ch == 'g') ch = '@';
	floor->updateView(row, col, ch);

	if (this->object[0] != NULL) {
		this->object[1] = object;
	} else {
		this->object[0] = object;
	}
}

Object* Cell::getObject(){
	if (object[1] == NULL) return object[0];
	else return object[1];	
}

void Cell::removeObject(){
	if (object[1] != NULL) {
		object[1] = NULL;
		char ch = object[0]->getType();
		floor->updateView(row, col, ch);
	} else {
		object[0] = NULL;
		floor->updateView(row, col, baseType);
	}
}

void Cell::addNeighbour(Cell* neighbour){
	for (int i = 0; i < 8; i++){
		if (neighbours[i] == NULL) {
			neighbours[i] = neighbour;
			return;
		}
	}
}

Cell** Cell::getNeighbours(){
	return neighbours;
}

int Cell::getRow() {return row;}
int Cell::getCol() {return col;}
char Cell::getBaseType() {return baseType;}
void Cell::setBaseType(char ch){
	this->baseType = ch;
	floor->updateView(row, col, baseType);
}

Cell::~Cell(){
	if (object[0] != NULL) delete object[0];
	if (object[1] != NULL) delete object[1];
}
