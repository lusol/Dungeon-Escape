#include "floor.h"
#include "game.h"

using namespace std;

void Floor::addNeighbours(int i, int j){
    if (i - 1 >= 0 && j - 1 >= 0) grid[i][j].addNeighbour(&grid[i - 1][j - 1]);
    if (j - 1 >= 0) grid[i][j].addNeighbour(&grid[i][j - 1]);
	if (i + 1 < rowSize && j - 1 >= 0) grid[i][j].addNeighbour(&grid[i + 1][j - 1]);
	if (i + 1 < rowSize) grid[i][j].addNeighbour(&grid[i + 1][j]);
	if (i + 1 < rowSize && j + 1 < colSize) grid[i][j].addNeighbour(&grid[i + 1][j + 1]);
    if (j + 1 < colSize) grid[i][j].addNeighbour(&grid[i][j + 1]);
    if (i - 1 >= 0 && j + 1 < colSize) grid[i][j].addNeighbour(&grid[i - 1][j + 1]);
    if (i - 1 >= 0) grid[i][j].addNeighbour(&grid[i - 1][j]);
}

Floor::Floor(Game* game, int rowSize, int colSize, ifstream &ifs){
    this->game = game;
    this->rowSize = rowSize;
    this->colSize = colSize;

    grid = new Cell*[rowSize];
    for (int i = 0; i < rowSize; i++){
        grid[i]= new Cell[colSize];
    }
    
    char ch;
    for(int i = 0; i < rowSize; i++){
        for(int j = 0; j < colSize; j++){
            ifs >> noskipws >> ch;
            if (ch == '\n') ifs >> noskipws >> ch;
            grid[i][j].init(this, i, j, ch);
            game->updateView(i, j, ch);
            addNeighbours(i, j);
        }
    }
}

Floor::Floor(Game* game, int rowSize, int colSize){
	this->game = game;
    this->rowSize = rowSize;
    this->colSize = colSize;

    ifstream ifs(MAPFILE.c_str());

    grid = new Cell*[rowSize];
    for (int i = 0; i < rowSize; i++){
        grid[i]= new Cell[colSize];
    }
    
    char ch;
    for(int i = 0; i < rowSize; i++){
        for(int j = 0; j < colSize; j++){
            ifs >> noskipws >> ch;
            if (ch == '\n') ifs >> noskipws >> ch;
            grid[i][j].init(this, i, j, ch);
            game->updateView(i, j, ch);
            addNeighbours(i, j);
        }
    }

    for (int i = 0; i < rowSize; i++){
    	for (int j = 0; j < colSize; j++){
    		if (grid[i][j].getBaseType() == '.'){
            	for (int k = 0; k < 5; k++){
            		if (chambers[k].isMember(&grid[i][j])) {
            			break;
            		} else if (chambers[k].isEmpty()) {
            			chambers[k].setCells(&grid[i][j]);
            			break;
            		}
            	}
            }
    	}
    }
}

void Floor::updateView(int row, int col, char ch){
	game->updateView(row, col, ch);
}

Chamber* Floor::getChambers(){
	return chambers;
}

Floor::~Floor(){
    for (int i = 0; i < rowSize; i++){
        delete[] grid[i];
    }
    delete[] grid;
}
