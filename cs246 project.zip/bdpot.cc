#include "bdpot.h"
#include <iostream>

BDPot::BDPot(Game *game){
	this->game = game;
	cell = NULL;
	row = -1;
	col = -1;
	type = '1';
	canPickup = true;
	revealed = false;
}

void BDPot::pickedup(){
	if(game->player->getType() == 'd'){
		game->player->pe->setDef(game->player->pe->getDef()+7);
	}
	{
		game->player->pe->setAtk(game->player->pe->getDef()+5);
	}
	
}
bool BDPot::isRevealed(){
	return revealed;
}

void BDPot::switchRevealed(){
	revealed = !revealed;
}