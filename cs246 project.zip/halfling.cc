#include "enemy.h"
#include "halfling.h"
#include "player.h"

Halfling::Halfling(Game *game){
    this->game = game;
    cell = NULL;
    row = -1;
    col = -1;
    type = 'L';
    atk = 15;
    def = 20;
    hp = 100;
    aggressive = true;
}

void Halfling::attack(Player &player){
    player.Defend(this);    
}