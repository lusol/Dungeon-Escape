#include "object.h"


Object::~Object() {}

int Object::getRow(){
	return row;
}

int Object::getCol(){
	return col;
}

void Object::setCoords(int row, int col){
	this->row = row;
	this->col - col;
}

char Object::getType(){
	return type;
}

void Object::setCell(Cell* cell){
	this->cell = cell;
}

Cell* Object::getCell(){
	return cell;
}
