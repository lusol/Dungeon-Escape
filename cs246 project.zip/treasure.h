#ifndef TREASURE_H
#define TREASURE_H
#include 
class Treasure:public Item{
	int value;
	public:
	Treasure(Game *game, int val);
	virtual void pickedUp();		
};
