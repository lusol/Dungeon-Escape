#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "game.h"
#include "view.h"
#include <iostream>

class Controller : gameNotification{
  Game* game;
  std::string fileName;
  View* view;
  void init();
public:
  Controller(std::string filename);
  Controller();
  ~Controller();
  void updateCell(int row, int col, char ch);
  void play();
};

#endif