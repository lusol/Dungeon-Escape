#ifndef PLAYER_H
#define PLAYER_H
#include "object.h"
#include "potioneffect.h"
#include <iostream>

class Enemy;

class Player : public Object {
protected:
        int atk;
        int def;
        int gold;
        int hp;
        int maxHP;
      PotionEffect *pe;
public:
      virtual ~Player() = 0;
      int getAtk();
      int getDef();
      int getHP();
      int getMaxHP();
      void setMaxHP(int hp);
      void setHP(int hp);
      void setGold(int gold);
      static Player* PlayerFactory(char race, Game *game);
      virtual void Attack(Enemy *enemy) = 0;
      bool Defend(Enemy *enemy);
      void Move(std::string direction);
      void atkEnemy(Enemy* enemy);
};


#endif
