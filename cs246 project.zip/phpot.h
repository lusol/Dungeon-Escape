#ifndef PHPOT_H
#define PHPOT_H
#include "potion.h"
class PHPot:public Potion{
static bool revealed;
public:
PHPot(Game *game);
void  pickedup();
bool isRevealed();
void switchRevealed();
};

#endif