#include "potion.h"

//destructor
Potion::~Potion(){}
